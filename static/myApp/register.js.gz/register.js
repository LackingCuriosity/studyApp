document.addEventListener("DOMContentLoaded", () => {
    console.log("DSd")
    if (document.getElementById("messageDiv").innerHTML == "") {
        document.getElementById("messageDiv").innerHTML = "WARNING THIS SITE WAS NOT BUILT WITH SECURITY AND CRYPTOGRAPY IN MIND. PLEASE DO NOT USE THE SAME OR SIMILAR CREDENTIALS AS OTHER SITES"
}
})